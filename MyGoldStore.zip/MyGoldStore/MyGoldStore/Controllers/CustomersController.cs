﻿using Microsoft.AspNetCore.Mvc;
using MyGoldStore.Controllers.Data;
using MyGoldStore.Models.Domain;
using MyGoldStore.Models;
using Microsoft.EntityFrameworkCore;
using System.Text.RegularExpressions;

namespace MyGoldStore.Controllers
{
    public class CustomersController : Controller
    {
        private readonly MVCDemoDbContext mvcDemoDbContext;

        public CustomersController(MVCDemoDbContext mvcDemoDbContext)
        {
            this.mvcDemoDbContext = mvcDemoDbContext;
        }

        [HttpGet]
        public async Task<IActionResult> Index()
        {
            var customers = await mvcDemoDbContext.Customers.ToListAsync();
            return View(customers);
        }
        [HttpGet]
        public IActionResult Add()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Add(AddCustomerViewModel addCustomerRequest)
        {
            var customer = new Customer()
            {

                Id = Guid.NewGuid(),
                Name = addCustomerRequest.Name,
                Ornaments = addCustomerRequest.Ornaments,
                Weight = addCustomerRequest.Weight,
                Price = addCustomerRequest.Price,
                Phone = addCustomerRequest.Phone,
                OrderDate = addCustomerRequest.OrderDate,
                DeliveryDate = addCustomerRequest.DeliveryDate,
            };

            await mvcDemoDbContext.Customers.AddAsync(customer);
            await mvcDemoDbContext.SaveChangesAsync();
            return RedirectToAction("Add");

        }

        [HttpGet]
        public async Task<IActionResult> View(Guid id) 
        {
           var customer = await mvcDemoDbContext.Customers.FirstOrDefaultAsync(x => x.Id == id);
            if (customer != null)
            {
                var viewmodel = new UpdateCustomerViewModel()
                {
                    Id = customer.Id,
                    Name = customer.Name,
                    Ornaments = customer.Ornaments,
                    Weight = customer.Weight,
                    Price = customer.Price,
                    Phone = customer.Phone,
                    OrderDate = customer.OrderDate,
                    DeliveryDate = customer.DeliveryDate

                };
                //return View(viewmodel);     
                return await Task.Run(() => View("View",viewmodel));
            }
            return RedirectToAction("Index");
        }

        [HttpPost]
        public async Task<IActionResult> View(UpdateCustomerViewModel model)
        {
            var customer = await mvcDemoDbContext.Customers.FindAsync(model.Id);
            if (customer != null)
            {
                customer.Name= model.Name;
                customer.Ornaments= model.Ornaments;
                customer.Weight= model.Weight;
                customer.Price= model.Price;
                customer.Phone= model.Phone;
                customer.OrderDate= model.OrderDate;
                customer.DeliveryDate= model.DeliveryDate;

                await mvcDemoDbContext.SaveChangesAsync();

                return RedirectToAction("Index");
            }

            return RedirectToAction("Index");
        }

        [HttpPost]
        public async Task<IActionResult> Delete(UpdateCustomerViewModel model)
        {
            var customer= await mvcDemoDbContext.Customers.FindAsync(model.Id);

            if(customer != null)
            {
                mvcDemoDbContext.Customers.Remove(customer);
                await mvcDemoDbContext.SaveChangesAsync();

                return RedirectToAction("Index");

            }
            return RedirectToAction("Index");
        }


    }
}
