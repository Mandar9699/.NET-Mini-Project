﻿namespace MyGoldStore.Models.Domain
{
    public class Customer
    {
        public Guid Id { get; set; }
        public String Name { get; set; }
        public String Ornaments { get; set; }
        public long Weight { get; set; }
        public long Price { get; set; }
        public String Phone { get; set; }
        public DateTime OrderDate { get; set; }
        public DateTime DeliveryDate { get; set; }
    }
}
